import config

# cfg = config.Config('helper/mysql.cfg')
config = {
  'user': 'root',
  'password': 'Hangzhou123',
  'host': 'localhost',
  'database': 'china_stock_wiki',
  'raise_on_warnings': True,
  'allow_local_infile': False
}